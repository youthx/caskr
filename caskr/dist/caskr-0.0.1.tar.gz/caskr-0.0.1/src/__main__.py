
def main() -> int:
    return 0
