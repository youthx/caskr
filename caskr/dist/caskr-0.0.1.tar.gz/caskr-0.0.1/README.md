# caskr

[![PyPI - Version](https://img.shields.io/pypi/v/caskr.svg)](https://pypi.org/project/caskr)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/caskr.svg)](https://pypi.org/project/caskr)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install caskr
```

## License

`caskr` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
