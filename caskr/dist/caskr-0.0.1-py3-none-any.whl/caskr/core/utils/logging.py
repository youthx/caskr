
import logging as _logging,
from logging import DEBUG, INFO, WARNING, ERROR, CRITICAL 

LOG_LEVEL = DEBUG

_logging.basicConfig(level=LOG_LEVEL)